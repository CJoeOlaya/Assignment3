public class Book{
    private String name;
    private Author author;
    private double price;
    private int qtyInStock;
    
    public Book(String name, Author author, double price, int qtyInStock){
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtyInStock = qtyInStock;
    }
    public String getName(){
        return name;
    }
    public Author getAuthor(){
        return author;
    }
    public int getStock(){
        return qtyInStock;
    }
    public double getPrice(){
        return price;
    }
    public void setPrice(double price){
        this.price =price;
    }
    public void setStock(int qtyInStock){
        this.qtyInStock = qtyInStock;
    }
    
    
    
    public static void main(String[] args) {
    Author washington = new Author ("Nicki Washington", "washingtonn@winthrop.edu", 'f');
    Book toc = new Book ("Stay Prepped: 10 Steps to Succeeding in College (and Having a Ball Doint It)", washington, 14.95, 1908);
        System.out.println(toc.getName() + " " + toc.getPrice() + " " + toc.getStock());
        System.out.println(washington.getName() + "  " + washington.getEmail() + "  " + washington.getGender());
}
}