public class Author{
    
   private static String name;
   private static String email;
   private static Character gender;
   public Author(String name, String email, Character gender){
       this.name = name;
       this.email = email;
       this.gender = gender;
   }
   public String getName(){
       return name;
   }
   public String getEmail(){
       return email;
   }
   public Character getGender(){
       return gender;
   }
   public void setEmail(String email){
       this.email = email;
   }
   
   
   
   public static void main(String[] args) {
   Author washington = new Author(" Nicki Washingtong", "washingtonn@winthrop.edu", 'f');
       System.out.println("The author is " + name + " their email is " + email + " their gender is " + gender);
   
   }
}